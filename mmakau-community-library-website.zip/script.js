const now = new Date();
const day = now.getDay(); // 0 = Sunday, 6 = Saturday
const hour = now.getHours();
const minute = now.getMinutes();
const currentMinutes = hour * 60 + minute;

const status = document.getElementById("todayStatus");
const message = document.getElementById("todayMessage");
const dot = document.querySelector(".status-dot");

const weekday = day >= 1 && day <= 5;
const openNow = weekday && currentMinutes >= 9 * 60 && currentMinutes < 17 * 60;

if (openNow) {
  status.textContent = "The library is open now";
  message.textContent = "Open today until 17:00.";
  dot.style.background = "#2e8b57";
} else if (weekday) {
  status.textContent = "The library is currently closed";
  message.textContent = "Weekday opening hours are 09:00–17:00.";
  dot.style.background = "#a94b4b";
} else {
  status.textContent = "The library is closed today";
  message.textContent = "Saturday & Sunday: Closed.";
  dot.style.background = "#a94b4b";
}

document.getElementById("year").textContent = new Date().getFullYear();
